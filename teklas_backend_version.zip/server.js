const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 5000; 

// Configuração do EJS para renderizar o resultado
app.set('view engine', 'ejs');
app.set('views', __dirname); 

app.use(express.static(__dirname)); 
app.use(express.json({ limit: '50mb' })); 
app.use(express.urlencoded({ limit: '50mb', extended: true }));

const DB_PATH = path.join(__dirname, 'consultas.json');
const EXPIRATION_TIME = 10 * 60 * 1000; // 10 minutos

if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([], null, 2));
}

function lerBanco() {
    try {
        const data = fs.readFileSync(DB_PATH);
        return JSON.parse(data);
    } catch (err) { return []; }
}

function salvarBanco(dados) {
    try { fs.writeFileSync(DB_PATH, JSON.stringify(dados, null, 2)); } catch (err) {}
}

// Rota principal (Home)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Endpoint /salvar para o bot
app.post('/salvar', (req, res) => {
    const { dados, foto } = req.body;
    if (!dados) return res.status(400).json({ erro: "Sem dados." });

    const id = uuidv4().split('-')[0].toUpperCase(); // ID mais curto e bonito
    const banco = lerBanco();
    
    banco.push({ id, dados, foto, criadoEm: Date.now() });
    salvarBanco(banco);

    // Retorna o link completo para o bot
    const link = `${req.protocol}://${req.get('host')}/resultado/${id}`;
    return res.json({ link: link });
});

// Rota de resultado
app.get('/resultado/:id', (req, res) => {
    const { id } = req.params;
    const agora = Date.now();
    let banco = lerBanco();
    const registro = banco.find(c => c.id === id);

    if (!registro || (agora - registro.criadoEm > EXPIRATION_TIME)) {
        return res.status(410).send("<h1>Sessão Expirada ou Não Encontrada</h1><p>Realize uma nova consulta no bot.</p>");
    }

    // Renderiza o arquivo resultado.ejs (vamos renomear o resultado.html para .ejs)
    res.render('resultado', { dados: registro.dados, result_id: id });
});

app.listen(PORT, () => {
    console.log(`\n  [!] TEKLAS CONSULTORIA ATIVO`);
    console.log(`  [+] ESCUTANDO NA PORTA: ${PORT}\n`);
});
